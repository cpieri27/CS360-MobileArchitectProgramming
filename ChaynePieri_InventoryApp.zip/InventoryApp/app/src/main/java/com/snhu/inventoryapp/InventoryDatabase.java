package com.snhu.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class InventoryDatabase extends SQLiteOpenHelper {

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UsersTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_PART_NUMBER = "part_number";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_QUANTITY = "quantity";
        private static final String COL_LOCATION = "location";
    }

    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        db.execSQL("create table " + UsersTable.TABLE + " (" +
                UsersTable.COL_ID + " integer primary key autoincrement, " +
                UsersTable.COL_USERNAME + " text, " +
                UsersTable.COL_PASSWORD + " text)");

        // Create inventory table
        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_PART_NUMBER+ " text primary key, " +
                InventoryTable.COL_DESCRIPTION+ " text, " +
                InventoryTable.COL_QUANTITY+ " integer, " +
                InventoryTable.COL_LOCATION + " text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UsersTable.TABLE);
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    // Add new user to users table
    public long addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UsersTable.COL_USERNAME, username);
        values.put(UsersTable.COL_PASSWORD, password);

        return db.insert(UsersTable.TABLE, null, values);
    }

    // Ensure credentials correct from users table
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        // Build query
        String[] columns = { UsersTable.COL_ID };
        String sql = "select * from " + UsersTable.TABLE + " where " +
                UsersTable.COL_USERNAME + " = ? and " + UsersTable.COL_PASSWORD + " = ?";
        String[] credentials = { username, password };

        // Run query
        Cursor cursor = db.rawQuery(sql, credentials);
        boolean isValid = cursor.moveToFirst();

        cursor.close();
        return isValid;
    }

    // Add part to inventory table
    public long addInventoryItem(String partNumber, String description, int quantity, String location) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_PART_NUMBER, partNumber);
        values.put(InventoryTable.COL_DESCRIPTION, description);
        values.put(InventoryTable.COL_QUANTITY, quantity);
        values.put(InventoryTable.COL_LOCATION, location);

        return db.insert(InventoryTable.TABLE, null, values);
    }

    // Update a part in inventory table
    public int updateInventoryItem(String partNumber, String description, int quantity, String location) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_DESCRIPTION, description);
        values.put(InventoryTable.COL_QUANTITY, quantity);
        values.put(InventoryTable.COL_LOCATION, location);

        String sql = InventoryTable.COL_PART_NUMBER + " = ?";
        String[] part = { partNumber };

        return db.update(InventoryTable.TABLE, values, sql, part);
    }

    // Delete part from inventory table
    public int deleteInventoryItem(String partNumber) {
        SQLiteDatabase db = getWritableDatabase();

        String sql = InventoryTable.COL_PART_NUMBER + " = ?";
        String[] part = { partNumber };

        return db.delete(InventoryTable.TABLE, sql, part);
    }

    // Get inventory to be displayed
    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + InventoryTable.TABLE;

        return db.rawQuery(sql, null);
    }

    // Check if part exists
    public boolean checkIfPartExists(String partNumber) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT COUNT(*) FROM " + InventoryTable.TABLE + " WHERE " + InventoryTable.COL_PART_NUMBER + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{partNumber});
        if (cursor != null) {
            cursor.moveToFirst();
            int count = cursor.getInt(0);
            cursor.close();
            return count > 0;
        }
        return false;
    }

    public Cursor searchInventoryItems(String query) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM " + InventoryTable.TABLE + " WHERE " +
                InventoryTable.COL_PART_NUMBER + " LIKE ? OR " +
                InventoryTable.COL_DESCRIPTION + " LIKE ? OR " +
                InventoryTable.COL_QUANTITY + " LIKE ? OR " +
                InventoryTable.COL_LOCATION + " LIKE ?";
        String[] selectionArgs = new String[]{"%" + query + "%", "%" + query + "%", "%" + query + "%", "%" + query + "%"};
        return db.rawQuery(sql, selectionArgs);
    }
}