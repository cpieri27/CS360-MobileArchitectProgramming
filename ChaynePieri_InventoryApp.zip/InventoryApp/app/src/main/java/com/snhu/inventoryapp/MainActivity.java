package com.snhu.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private InventoryDatabase mDBHelper;
    private RecyclerView mRecyclerView;
    private InventoryAdapter mAdapter;
    private List<InventoryItem> mInventoryList = new ArrayList<>();
    private EditText mPartNumberEditText, mDescriptionEditText, mQuantityEditText, mLocationEditText, mSearchBar;
    private ImageButton mClearAddButton, mSettingsButton;
    private Button mAddPartButton;
    private SharedPreferences mSharedPreferences;
    private static final String PREFS_NAME = "SMSPrefs";
    private static final String PREF_PHONE_NUMBER = "PhoneNumber";
    private static final String PREF_THRESHOLD = "Threshold";
    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDBHelper = new InventoryDatabase(this);
        mSharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        mRecyclerView = findViewById(R.id.inventory);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        DividerItemDecoration divider = new DividerItemDecoration(mRecyclerView.getContext(),
                DividerItemDecoration.VERTICAL);
        mRecyclerView.addItemDecoration(divider);

        mAdapter = new InventoryAdapter(mInventoryList);
        mRecyclerView.setAdapter(mAdapter);

        mPartNumberEditText = findViewById(R.id.part_number_add);
        mDescriptionEditText = findViewById(R.id.description_add);
        mQuantityEditText = findViewById(R.id.quantity_add);
        mLocationEditText = findViewById(R.id.location_add);
        mSearchBar = findViewById(R.id.search_bar);
        mClearAddButton = findViewById(R.id.clear_add_button);
        mAddPartButton = findViewById(R.id.add_part_button);
        mSettingsButton = findViewById(R.id.settings_button);

        mSettingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SMSNotificationActivity.class);
                startActivity(intent);
            }
        });

        mAddPartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addOrUpdateInventoryItem();
            }
        });

        mClearAddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clearFields();
            }
        });

        mSearchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                loadInventory(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

        loadInventory(null);
    }

    private void loadInventory(String query) {
        mInventoryList.clear();
        Cursor cursor;
        if (query == null || query.isEmpty()) {
            cursor = mDBHelper.getAllInventoryItems();
        } else {
            cursor = mDBHelper.searchInventoryItems(query);
        }
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String partNumber = cursor.getString(cursor.getColumnIndexOrThrow("part_number"));
                String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
                String location = cursor.getString(cursor.getColumnIndexOrThrow("location"));
                mInventoryList.add(new InventoryItem(partNumber, description, quantity, location));
            }
            cursor.close();
        }
        mAdapter.notifyDataSetChanged();
    }

    private void addOrUpdateInventoryItem() {
        String partNumber = mPartNumberEditText.getText().toString();
        String description = mDescriptionEditText.getText().toString();
        String quantityStr = mQuantityEditText.getText().toString();
        String location = mLocationEditText.getText().toString();

        if (partNumber.isEmpty() || description.isEmpty() || quantityStr.isEmpty() || location.isEmpty()) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity = Integer.parseInt(quantityStr);

        // Check if the part number already exists
        if (mDBHelper.checkIfPartExists(partNumber)) {
            // Update the existing part
            int rowsAffected = mDBHelper.updateInventoryItem(partNumber, description, quantity, location);
            if (rowsAffected > 0) {
                loadInventory(null);
                clearFields();
                checkAndSendSMSIfNeeded(partNumber, quantity);
                Toast.makeText(this, "Part updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                showAlert("Failed to update part.");
            }
        } else {
            // Add a new part
            long newRowId = mDBHelper.addInventoryItem(partNumber, description, quantity, location);
            if (newRowId != -1) {
                loadInventory(null);
                clearFields();
                checkAndSendSMSIfNeeded(partNumber, quantity);
                Toast.makeText(this, "Part added successfully", Toast.LENGTH_SHORT).show();
            } else {
                showAlert("Failed to add part.");
            }
        }
    }

    private void checkAndSendSMSIfNeeded(String partNumber, int quantity) {
        String thresholdString = mSharedPreferences.getString(PREF_THRESHOLD, "");
        String phoneNumber = mSharedPreferences.getString(PREF_PHONE_NUMBER, "");

        if (!thresholdString.isEmpty() && !phoneNumber.isEmpty()) {
            int threshold = Integer.parseInt(thresholdString);
            if (quantity < threshold) {
                sendSMS(phoneNumber, "Inventory Alert: Quantity of part " + partNumber + " is below the threshold.");
            }
        }
    }

    private void sendSMS(String phoneNumber, String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        } else {
            // Request the SMS permission if it hasn't been granted
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                // Permission denied
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void clearFields() {
        mPartNumberEditText.setText("");
        mDescriptionEditText.setText("");
        mQuantityEditText.setText("");
        mLocationEditText.setText("");
    }

    private void showAlert(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }
}