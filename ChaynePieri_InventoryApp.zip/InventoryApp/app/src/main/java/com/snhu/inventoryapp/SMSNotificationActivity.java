package com.snhu.inventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSNotificationActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 100;
    private static final String PREFS_NAME = "SMSPrefs";
    private static final String PREF_PHONE_NUMBER = "PhoneNumber";
    private static final String PREF_THRESHOLD = "Threshold";

    private TextView smsStatus;
    private EditText mPhoneNumberEdit, mThresholdEdit;
    private Button mApplyPhoneNumberButton, mApplyThresholdButton;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        smsStatus = findViewById(R.id.sms_status);
        mPhoneNumberEdit = findViewById(R.id.phone_number_edit);
        mThresholdEdit = findViewById(R.id.threshold_edit);
        mApplyPhoneNumberButton = findViewById(R.id.apply_phone_number_button);
        mApplyThresholdButton = findViewById(R.id.apply_threshold_button);
        Button requestPermissionButton = findViewById(R.id.request_sms_permission_button);

        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        mApplyPhoneNumberButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savePhoneNumber();
            }
        });

        mApplyThresholdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveThreshold();
            }
        });

        requestPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSMSPermission();
            }
        });

        loadPhoneNumber();
        loadThreshold();
        updateSMSStatus();
    }

    private void requestSMSPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    private void updateSMSStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            smsStatus.setText(R.string.sms_enabled);
        } else {
            smsStatus.setText(R.string.sms_disabled);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                smsStatus.setText(R.string.sms_enabled);
            } else {
                smsStatus.setText(R.string.sms_disabled);
            }
        }
    }

    private void savePhoneNumber() {
        String phoneNumber = mPhoneNumberEdit.getText().toString();
        if (!phoneNumber.isEmpty()) {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(PREF_PHONE_NUMBER, phoneNumber);
            editor.apply();
            Toast.makeText(this, "Phone number saved", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please enter a phone number", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadPhoneNumber() {
        String phoneNumber = sharedPreferences.getString(PREF_PHONE_NUMBER, "");
        if (!phoneNumber.isEmpty()) {
            mPhoneNumberEdit.setText(phoneNumber);
        }
    }

    private void saveThreshold() {
        String threshold = mThresholdEdit.getText().toString();
        if (!threshold.isEmpty()) {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(PREF_THRESHOLD, threshold);
            editor.apply();
            Toast.makeText(this, "Threshold saved", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please enter a threshold value", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadThreshold() {
        String threshold = sharedPreferences.getString(PREF_THRESHOLD, "");
        if (!threshold.isEmpty()) {
            mThresholdEdit.setText(threshold);
        }
    }
}