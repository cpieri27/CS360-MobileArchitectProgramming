package com.snhu.inventoryapp;

public class InventoryItem {
    private String mPartNumber;
    private String mDescription;
    private int mQuantity;
    private String mLocation;

    public InventoryItem(String partNumber, String description, int quantity, String location) {
        this.mPartNumber = partNumber;
        this.mDescription = description;
        this.mQuantity = quantity;
        this.mLocation = location;
    }

    public String getPartNumber() {
        return mPartNumber;
    }

    public String getDescription() {
        return mDescription;
    }

    public int getQuantity() {
        return mQuantity;
    }

    public String getLocation() {
        return mLocation;
    }
}