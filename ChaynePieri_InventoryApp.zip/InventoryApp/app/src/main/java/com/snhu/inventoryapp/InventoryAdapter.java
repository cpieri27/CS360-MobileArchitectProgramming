package com.snhu.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private List<InventoryItem> mInventoryList;
    private InventoryDatabase mDBHelper;

    public InventoryAdapter(List<InventoryItem>mInventoryList) {
        this.mInventoryList =mInventoryList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_inventory, parent, false);
        mDBHelper = new InventoryDatabase(parent.getContext());
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item =mInventoryList.get(position);
        holder.partNumber.setText(item.getPartNumber());
        holder.description.setText(item.getDescription());
        holder.quantity.setText(String.valueOf(item.getQuantity()));
        holder.location.setText(item.getLocation());
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Implement delete functionality
                mDBHelper.deleteInventoryItem(item.getPartNumber());
                mInventoryList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position,mInventoryList.size());
            }
        });
    }

    @Override
    public int getItemCount() {
        return mInventoryList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView partNumber, description, quantity, location;
        public ImageButton deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            partNumber = itemView.findViewById(R.id.part_number);
            description = itemView.findViewById(R.id.description);
            quantity = itemView.findViewById(R.id.quantity);
            location = itemView.findViewById(R.id.location);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}